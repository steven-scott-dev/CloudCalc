// server/index.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./models');
const userRoutes = require('./routes/users');
const historyRoutes = require('./routes/history');

const app = express();

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('⚠️  Missing JWT_SECRET in environment! Add it to your .env');
  process.exit(1);
}

// Allow requests from your React dev server:
app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(express.json());

// Mount user‑auth routes at /users
app.use('/users', userRoutes);
// Mount calculation‑history routes at /api/history
app.use('/api/history', historyRoutes);

// Sync models & start server
db.sequelize.sync()
  .then(() => console.log('✅ Database synced'))
  .catch(err => console.error('🚨 DB sync error:', err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
