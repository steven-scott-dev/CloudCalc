// src/App.js
import React, { useState } from 'react';
import './App.css';
import SignupForm from './components/SignupForm';
import LoginForm  from './components/LoginForm';
import Calculator from './components/Calculator';

function App() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState('login'); // 'login' | 'signup' | 'guest'

  // if they’ve authenticated or chosen guest, show calculator
  if (user || view === 'guest') {
    return <Calculator />;
  }

  return (
    <div className="App">
      <div className="auth-toggle">
        <button
          className={view === 'login' ? 'active' : ''}
          onClick={() => setView('login')}
        >
          Login
        </button>
        <button
          className={view === 'signup' ? 'active' : ''}
          onClick={() => setView('signup')}
        >
          Sign Up
        </button>
        <button
          className={view === 'guest' ? 'active' : ''}
          onClick={() => setView('guest')}
        >
          Use as Guest
        </button>
      </div>

      <div className="auth-form-container">
        {view === 'login' && <LoginForm  onAuth={setUser} />}
        {view === 'signup' && <SignupForm onAuth={setUser} />}
        {/* view==='guest' will fall through to above */}
      </div>
    </div>
  );
}

export default App;
