// src/components/Calculator.js
import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { evaluate } from 'mathjs';
import './Calculator.css';

const Calculator = () => {
  const [input, setInput] = useState('');
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState([]);

  // Fetch history (protected by JWT)
  const fetchHistory = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/history', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setHistory(res.data);
    } catch (err) {
      console.error('Error fetching history:', err);
    }
  }, []);

  // Load history on mount
  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // Calculate result, save to backend, then refresh history
  const handleEqual = useCallback(async () => {
    try {
      const result = evaluate(input).toString();
      setInput(result);
      setCopied(false);

      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/history',
        { expression: input, result },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchHistory();
    } catch (err) {
      console.error(err);
      setInput('Error');
    }
  }, [input, fetchHistory]);

  // Clear the input
  const handleClear = useCallback(() => {
    setInput('');
    setCopied(false);
  }, []);

  // Keyboard shortcuts (Enter/= → calculate, C/Escape → clear)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Enter' || e.key === '=') {
        handleEqual();
      } else if (['c', 'C', 'Escape'].includes(e.key)) {
        handleClear();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleEqual, handleClear]);

  // Append a digit/operator to the input
  const handleClick = (value) => {
    setInput((prev) => prev + value);
    setCopied(false);
  };

  // Copy current display to clipboard
  const handleCopy = () => {
    navigator.clipboard.writeText(input);
    setCopied(true);
    setTimeout(() => setCopied(false), 1000);
  };

  return (
    <div className="app-container">
      <div className="calculator">
        <h1>CloudCalc</h1>

        <div className="input-wrapper">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter equation"
            readOnly
          />
          {copied && <div className="copied-animation">Copied!</div>}
        </div>

        <div className="button-row">
          <button onClick={() => handleClick('7')}>7</button>
          <button onClick={() => handleClick('8')}>8</button>
          <button onClick={() => handleClick('9')}>9</button>
          <button className="clear" onClick={handleClear}>C</button>
        </div>

        <div className="button-row">
          <button onClick={() => handleClick('4')}>4</button>
          <button onClick={() => handleClick('5')}>5</button>
          <button onClick={() => handleClick('6')}>6</button>
          <button className="operator" onClick={() => handleClick('*')}>×</button>
        </div>

        <div className="button-row">
          <button onClick={() => handleClick('1')}>1</button>
          <button onClick={() => handleClick('2')}>2</button>
          <button onClick={() => handleClick('3')}>3</button>
          <button className="operator" onClick={() => handleClick('-')}>−</button>
        </div>

        <div className="button-row">
          <button onClick={() => handleClick('0')}>0</button>
          <button className="operator" onClick={() => handleClick('.')}>.</button>
          <button className="operator" onClick={() => handleClick('+')}>+</button>
          <button className="operator" onClick={() => handleClick('/')}>÷</button>
        </div>

        <div className="button-row">
          <button className="equals" onClick={handleEqual}>=</button>
        </div>

        <div className="button-row">
          <button onClick={handleCopy}>{copied ? 'Copied!' : 'Copy'}</button>
        </div>
      </div>

      <div className="history-panel">
        <h2>History</h2>
        {history.length === 0 ? (
          <p>No history yet.</p>
        ) : (
          <ul>
            {history.map((item) => (
              <li key={item.id}>
                {item.expression} = {item.result}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Calculator;
